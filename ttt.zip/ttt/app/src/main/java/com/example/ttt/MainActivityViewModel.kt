package com.example.ttt

import androidx.lifecycle.ViewModel
import androidx.lifecycle.MutableLiveData
import com.example.ttt.models.Board
import com.example.ttt.models.BoardState
import com.example.ttt.models.Cell
import com.example.ttt.models.CellState

class MainActivityViewModel :ViewModel(){
    var board = Board()
    val liveBoard = MutableLiveData<Board> (board)

    /** @param **/
    fun cellClicked(cell: Cell) {
        board.setCell(cell, CellState.Star)
        updateBoard()

        if(board.boardState == BoardState.INCOMPLETE){
            aiTurn()
        }
    }
    /** **/
    fun resetBoard() {
        board.resetBoard()
        updateBoard()
    }


    /** live update **/
    private fun updateBoard(){
        liveBoard.value = board
    }

    /** bot player  **/
    private fun aiTurn() {
        val aiWin = board.findNextWinningMove(CellState.Circle)
        val playerWin = board.findNextWinningMove(CellState.Star)
        when{
            aiWin != null -> board.setCell(aiWin, CellState.Circle)
            playerWin != null -> board.setCell(playerWin, CellState.Star)
            board.setCell(Cell.CENTER_CENTER, CellState.Circle) -> Unit
            else -> do {
                val cell = Cell.values().random()
                val placedSuccessfully = board.setCell(cell, CellState.Circle)
            } while(!placedSuccessfully)
        }
        /** old bot algorithm
        do{
            val cell = Cell.values().random()
            val placedSuccessfully = board.setCell(cell, CellState.Circle)
        } while(!placedSuccessfully)
         **/
        updateBoard()

    }
}