package com.example.ttt.models

enum class BoardState {
    INCOMPLETE,
    STARS_WIN,
    CIRCLES_WIN,
    DRAW
}